METADATA:
--------
This folder is part of the repository of Data from 'Unveiling Climate-Adaptive World Heritage Management Strategies: the Netherlands as a Case Study'.

The folder consists of six published figures:
1) Codes and their associated sub-themes and themes from the datasets Management Plan (MP), State of Conservation (SoC) Report by the State Parties, and Statement of Outstanding Universal Value (SOUV).
2) Sankey diagram illustrating the SOUV dataset's hierarchical relationship.
3) Two semantic networks reflecting the occurrence frequencies of themes or sub-themes associated with a WH property, based on its referenced MP or SoC Report by the State Parties.

CREATORS:
Kai Cheang, Department of Archaeological Heritage and Society, Leiden University, 2333 CC Leiden, the Netherlands; s3423948@vuw.leidenuniv.nl
ORCID: 0009-0002-5231-5517 

Nan Bai, Department of Architectural Engineering and Technology, Delft University of Technology, 2628 BZ Delft, the Netherlands; N.Bai@tudelft.nl
ORCID: 0000-0001-7637-3629

Ana Pereira Roders, Department of Architectural Engineering and Technology, Delft University of Technology, 2628 BZ Delft, the Netherlands; A.R.Pereira-Roders@tudelft.nl
ORCID: 0000-0003-2571-9882

LICENSE: 
Attribution 4.0 International (CC BY 4.0)

INFORMATION AND CONTACT
--------
This README is prepared in May 2025 by Kai Cheang, Department of Archaeological Heritage and Society, Leiden University, 2333 CC Leiden, the Netherlands; s3423948@vuw.leidenuniv.nl
